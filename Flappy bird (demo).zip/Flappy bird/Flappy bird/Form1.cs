﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;


namespace Flappy_bird
{
    public partial class Form1 : Form
    {
        int pipeSpeed = 8;
        int gravity = 8;
        int score = 0;
        SoundPlayer soundPlayer = new SoundPlayer();

        public Form1()
        {
            InitializeComponent();
        }

        private void gametimer_Tick(object sender, EventArgs e)
        {
            bird.Top += gravity;
            pipeTop.Left -= pipeSpeed;
            pipedown.Left -= pipeSpeed;
            scoretext.Text = "Score: " + score.ToString();

            if (pipeTop.Left < -50)
            {
                pipeTop.Left = 900;
                score++;
            }

            if (pipedown.Left < -10)
            {
                pipedown.Left = 850;
                score++; 
            }

            if(bird.Bounds.IntersectsWith(pipedown.Bounds)||
               bird.Bounds.IntersectsWith(pipeTop.Bounds)||
               bird.Bounds.IntersectsWith(ground.Bounds))
            {
                endGame();
            }
        }

        private void endGame()
        {
            gametimer.Stop();
            scoretext.Text += "Game over!";

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Space)
            {
                gravity = -10  ;
            }
            soundPlayer.SoundLocation = @"";
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                gravity = 8;
            }

        }
    }
} 
